package com.nils2012629gmail.qrcodescaner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

//Implementierung von onclicklistener
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //View Objekt
    private Button buttonScan;
    private TextView textViewName, textViewSpannung, textViewLeistung, textViewStrom;

    //QR Code Scanner objekt
    private IntentIntegrator qrScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //View objekt
        buttonScan = (Button) findViewById(R.id.buttonScan);
        textViewName = (TextView) findViewById(R.id.textViewName);
        textViewSpannung = (TextView) findViewById(R.id.textViewSpannung);
        textViewLeistung = (TextView) findViewById(R.id.textViewLeistung);
        textViewStrom = (TextView) findViewById(R.id.textViewStrom);

        //Initialisieren des Scan-Objekts
        qrScan = new IntentIntegrator(this);

        //Anhängen onclick Listener
        buttonScan.setOnClickListener(this);
    }

    //Die Scan-Ergebnisse erhalten
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //Wenn QRcode nichts enthält
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //
                //wenn QR Daten enthält
                try {
                    //Konvertieren der Daten in JSON
                    JSONObject obj = new JSONObject(result.getContents());
                    //Festlegen von Werten für Textansichten
                    textViewName.setText(obj.getString("name"));
                    textViewSpannung.setText(obj.getString("spannung"));
                    textViewLeistung.setText(obj.getString("leistung"));
                    textViewStrom.setText(obj.getString("strom"));
                } catch (JSONException e) {
                    e.printStackTrace();
                    // wenn die Kontrolle hier kommt
                    // Das bedeutet, dass das codierte Format nicht übereinstimmt
                    // In diesem Fall können Sie anzeigen, welche Daten auf dem QRCode verfügbar sind
                    // zu einem Toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    @Override
    public void onClick(View view) {
        //Starten des qr-Code-Scans
        qrScan.initiateScan();
    }
}

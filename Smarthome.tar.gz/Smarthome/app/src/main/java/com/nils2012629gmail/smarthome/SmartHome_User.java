package com.nils2012629gmail.smarthome;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class SmartHome_User extends AppCompatActivity {

    private Button bt_send;
    private Button ft_send;
    private Button et_send;
    private TextView tv_motor;
    private TextView tv_tem;
    private TextView tv_abstand;

    private String send_buff=null;
    private String recv_buff=null;

    private Handler handler = null;

    Socket socket = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smarthome_user);

        initView();

        handler = new Handler();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    socket = new Socket("192.168.1.173" , 7654);
                    if (socket!=null) {
                        System.out.println("###################");
                        while (true) {
                            recv();
                            send();
                            Thread.sleep(50);
                        }
                    }
                    else
                        System.out.println("socket is null");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        send();
    }


    private void recv() {


        InputStream inputStream = null;
        try {
            inputStream = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (inputStream!=null){
            try {
                byte[] buffer = new byte[1024];
                int count = inputStream.read(buffer);//count是传输的字节数
                recv_buff = new String(buffer);
                System.out.println(recv_buff);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (recv_buff!=null){
            handler.post(runnableUi);

        }
    }


    Runnable runnableUi = new Runnable() {
        @Override
        public void run() {
            if (recv_buff.indexOf("o") != -1) {
                tv_motor.setText("\n" + recv_buff);
            } else if (recv_buff.indexOf("u") != -1) {
                tv_tem.setText("\n" + recv_buff);
            } else if (recv_buff.indexOf("a") != -1) {
                tv_abstand.setText("\n" + recv_buff);
            } else {
                tv_motor.setText("\n" + recv_buff);
            }
        }
    };


    private void send() {
        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        send_buff = "Motor";
                        //向服务器端发送消息
                        System.out.println("------------------------");
                        OutputStream outputStream=null;
                        try {
                            outputStream = socket.getOutputStream();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        if(outputStream!=null){
                            try {
                                outputStream.write(send_buff.getBytes());
                                System.out.println("1111111111111111111111");
                                outputStream.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }).start();

            }
        });

        ft_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        send_buff = "Temperatur";
                        //向服务器端发送消息
                        System.out.println("------------------------");
                        OutputStream outputStream=null;
                        try {
                            outputStream = socket.getOutputStream();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        if(outputStream!=null){
                            try {
                                outputStream.write(send_buff.getBytes());
                                System.out.println("1111111111111111111111");
                                outputStream.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }).start();

            }
        });

        et_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        send_buff = "Abstand";
                        //向服务器端发送消息
                        System.out.println("------------------------");
                        OutputStream outputStream=null;
                        try {
                            outputStream = socket.getOutputStream();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        if(outputStream!=null){
                            try {
                                outputStream.write(send_buff.getBytes());
                                System.out.println("1111111111111111111111");
                                outputStream.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }).start();

            }
        });
    }




    private void initView() {
        bt_send = (Button) findViewById(R.id.bt_send);
        ft_send = (Button) findViewById(R.id.ft_send);
        et_send = (Button) findViewById(R.id.et_send);
        tv_motor = (TextView) findViewById(R.id.tv_motor);
        tv_tem = (TextView) findViewById(R.id.tv_temp);
        tv_abstand = (TextView) findViewById(R.id.tv_abstand);
    }
}

